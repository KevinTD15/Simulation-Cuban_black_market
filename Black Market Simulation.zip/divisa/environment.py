import random
from agent import Agent
import pandas as pd

class Environment:

    def __init__(self):
        self.curr_day = 0
        self.buying_agents = []
        self.selling_agents = []

        self.calculate_stadigraphs(1,self.curr_day)

    def generate_agents(self, n, type):
        agents = []
        for i in range(n):
            agents.append(Agent(type))
        return agents

    def calculate_stadigraphs(self, n_days, curr_day):

        df_buy = pd.read_csv("buy_orders.csv")
        df_sell = pd.read_csv("sell_orders.csv")

        # df_sell get only records if abs(day-curr_day) < n_days
        df_sell = df_sell[(df_sell['day'] >= curr_day-n_days) & (df_sell['day'] <= curr_day)]        
        df_buy = df_buy[(df_buy['day'] >= curr_day-n_days) & (df_buy['day'] <= curr_day)]

        self.sell_mean = df_sell['price'].mean()
        self.sell_median = df_sell['price'].median()
        self.sell_mode = df_sell['price'].mode()[0]

        self.buy_mean = df_buy['price'].mean()
        self.buy_median = df_buy['price'].median()
        self.buy_mode = df_buy['price'].mode()[0]

    def reset_orders(self):
        df_buy = pd.read_csv("buy_orders.csv")
        df_sell = pd.read_csv("sell_orders.csv")

        df_buy = df_buy[df_buy['day'] == 0]
        df_sell = df_sell[df_sell['day'] == 0]

        df_buy.to_csv("buy_orders.csv", index=False)
        df_sell.to_csv("sell_orders.csv", index=False)
        
# load json data 