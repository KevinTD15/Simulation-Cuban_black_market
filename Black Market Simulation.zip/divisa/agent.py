import random
import pandas as pd

class Agent:
    def __init__(self, type):
        self.last_price_mean = 0
        self.last_price_median = 0
        self.last_price_mode = 0
        self.last_trend = 0
        self.range_publish = random.randint(0, 3)
        self.range_check = random.randint(0, 3)
        self.days_since_last_publish = 0
        self.days_since_last_check = 100
        self.type = type

    def check_price(self, price_mean, price_mode, price_median):
        self.last_price_mean = price_mean
        self.last_price_median = price_median
        self.last_price_mode = price_mode

    def update_trend(self, trend):
        self.last_trend = trend
        print("new_trend", trend)

    def publish_ad(self, curr_day):
        if self.last_trend >= 0:
            price = self.last_price_median + self.last_trend
        else:
            price = self.last_price_median + (-1 * self.last_trend)
        if self.type == 0:
            str = "sell_orders.csv"
        else:
            str = "buy_orders.csv"
        df = pd.read_csv(str)
        df = df.append({'day': curr_day, 'price': int(price)}, ignore_index=True)

        df.to_csv(str, index=False)