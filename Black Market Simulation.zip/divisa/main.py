from agent import Agent
from environment import Environment
import streamlit as st
# import random
import numpy as np
from numpy import random
import matplotlib.pyplot as plt
import pandas as pd

def simmulate():
    print("Simulador de comportamiento del mercado negro de divisas")
    print("""Se pretende analizar como influye en el mercado una herramienta informativa que muestre informacion sobre
            la oferta y demanda de monedas, se muestran los resultados utilizando como indicador diferentes estadigrafos 
            (moda media o mediana) y la influencia de cada uno de estos en el mercado""")

    env = Environment()

    n_buyers = int(input("cantidad de compradores: "))
    n_sellers = int(input("cantidad de vendedores: "))

    env.buying_agents = env.generate_agents(n_buyers, 1)
    env.selling_agents = env.generate_agents(n_sellers, 0)

    normal = lambda n : random.normal(loc=1,scale=1, size=n)
    uniform = lambda n : random.uniform(low=-5, high=5, size=n)
    exponential = lambda n : random.exponential(scale=1,size=n)
    poisson = lambda n : random.poisson(lam=2, size=n)
    sigmoid = lambda n : random.logistic(1,2)

    distributions = {
        "normal" : normal,
        "uniform": uniform,
        "exponential": exponential,
        "poisson": poisson, 
        "sigmoid": sigmoid
    }

    next_iter_dist = input("distribution: ")

    # nex_iter_dist = st.selectbox("Distribucion utilizada para afectar el mercado", distributions.keys())

    list = []


    days_to_sim = int(input("dias a simular: "))

    # days_to_sim = st.number_input("Cantidad de dias que se desean simular seguidos", step=1)
    if days_to_sim > 0:
    # if st.button("run round(s)"):
        for i in range(days_to_sim):
            env.curr_day += 1
            env.calculate_stadigraphs(1,env.curr_day)

            for id,agent in enumerate(env.buying_agents):
                agent.days_since_last_check += 1
                agent.days_since_last_publish += 1
                
                if agent.days_since_last_check >= agent.range_check:
                    print(f"Buying Agent {id} is checking the market")
                    agent.days_since_last_check = 0
                    agent.check_price((env.buy_mean+env.sell_mean)/2, (env.buy_median+env.sell_median)/2, (env.buy_mode+env.sell_mode)/2)
                    agent.update_trend(distributions[next_iter_dist](1))

                if agent.days_since_last_publish >= agent.range_publish:
                    print(f"Buying Agent {id} is publishing in the market")
                    agent.days_since_last_publish = 0
                    agent.publish_ad(env.curr_day)
                    
            for id,agent in enumerate(env.selling_agents):
                agent.days_since_last_check += 1
                agent.days_since_last_publish += 1
                
                if agent.days_since_last_check >= agent.range_check:
                    print(f"Selling Agent {id} is checking the market")
                    agent.days_since_last_check = 0
                    agent.check_price((env.buy_mean+env.sell_mean)/2, (env.buy_median+env.sell_median)/2, (env.buy_mode+env.sell_mode)/2)
                    agent.update_trend(distributions[next_iter_dist](1))

                if agent.days_since_last_publish >= agent.range_publish:
                    print(f"Selling Agent {id} is publishing in the market")
                    agent.days_since_last_publish = 0
                    agent.publish_ad(env.curr_day)

            env.buy_mean = env.buy_mean + abs(agent.last_trend)
            env.buy_mean = env.buy_median + abs(agent.last_trend)
            env.buy_mean = env.buy_mode + abs(agent.last_trend)

            env.sell_mean = env.sell_mean + abs(agent.last_trend)
            env.sell_median = env.sell_median + abs(agent.last_trend)
            env.sell_mode = env.buy_mode + abs(agent.last_trend)

    print("Simulacion finalizada\n precio final: ", (env.sell_mean+env.buy_mean)/2)
    print("Simulacion finalizada\n precio final: ", (env.sell_mode+env.buy_mode)/2)
    print("Simulacion finalizada\n precio final: ", (env.sell_median+env.buy_median)/2)

def main():
    print("Seleccione accion a realizar:")
    print("""
          1 - Simular
          2 - Reiniciar 
          3 - Salir
          """)
    opt = int(input("opcion: "))
    if opt == 1:
        simmulate()
        print()
        main()
    elif opt == 2:
        df_buy = pd.read_csv("buy_orders.csv")
        df_sell = pd.read_csv("sell_orders.csv")

        df_buy = df_buy[df_buy['day'] == 0]
        df_sell = df_sell[df_sell['day'] == 0]

        df_buy.to_csv("buy_orders.csv", index=False)
        df_sell.to_csv("sell_orders.csv", index=False)
        
        print()
        main()
    elif opt == 3:
        print("Good bye!")
    else:
        main()

if __name__ == '__main__':
    main()